#version 300 es
#define ae_insert_flip_uniform
#undef ae_insert_flip_uniform

uniform vec2 u_scale;
uniform int u_ctrl_count;
uniform vec4 u_ctrl_vec[128];
uniform float u_ratio;
uniform vec2 u_scale_inv;

layout(location = 1) in vec2 attTexcoord0;
layout(location = 0) in vec3 attPosition;
out vec2 textureCoordinate;

void main()
{
    gl_Position = vec4(attPosition, 1.0);
    if (u_ctrl_count > 0)
    {
        float _454;
        vec4 _455;
        _455 = vec4(0.0);
        _454 = 0.0;
        for (int _453 = 0; _453 < u_ctrl_count; )
        {
            vec2 _301 = (-attTexcoord0) * u_scale + u_ctrl_vec[_453].zw;
            vec2 _304 = _301 * _301;
            float _315 = 1.0 / (((_304.x + _304.y) * 0.25 + (500.0 * u_ratio)) + 9.9999997473787516355514526367188e-06);
            _455 += (u_ctrl_vec[_453] * _315);
            _454 += _315;
            _453++;
            continue;
        }
        vec4 _331 = _455 / vec4(_454);
        vec2 _335 = attTexcoord0 * u_scale + (-_331.zw);
        vec2 _457;
        float _458;
        _458 = 0.0;
        _457 = vec2(0.0);
        for (int _456 = 0; _456 < u_ctrl_count; )
        {
            vec4 _347 = u_ctrl_vec[_456] - _331;
            vec2 _351 = (-attTexcoord0) * u_scale + u_ctrl_vec[_456].zw;
            vec2 _354 = _351 * _351;
            float _365 = 1.0 / (((_354.x + _354.y) * 0.25 + (500.0 * u_ratio)) + 9.9999997473787516355514526367188e-06);
            vec2 _372 = _347.xy;
            vec2 _374 = _347.zw;
            vec2 _375 = _372 * _374;
            vec2 _379 = _372 * vec2(_347.wz);
            float _389 = _379.x - _379.y;
            vec2 _392 = _335 * _365;
            vec2 _417 = _374 * _374;
            _458 = _365 * (_417.x + _417.y) + _458;
            _457 += (vec2(_392.yx) * vec2(_389, -_389) + (_392 * (_375.x + _375.y)));
            _456++;
            continue;
        }
        textureCoordinate = clamp(((_457 / vec2(_458)) + _331.xy) * u_scale_inv, vec2(0.0), vec2(1.0));
    }
    else
    {
        textureCoordinate = clamp(attTexcoord0, vec2(0.0), vec2(1.0));
    }
}

