#pragma clang diagnostic ignored "-Wmissing-prototypes"
#pragma clang diagnostic ignored "-Wmissing-braces"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template<typename T, size_t Num>
struct spvUnsafeArray
{
    T elements[Num ? Num : 1];
    
    thread T& operator [] (size_t pos) thread
    {
        return elements[pos];
    }
    constexpr const thread T& operator [] (size_t pos) const thread
    {
        return elements[pos];
    }
    
    device T& operator [] (size_t pos) device
    {
        return elements[pos];
    }
    constexpr const device T& operator [] (size_t pos) const device
    {
        return elements[pos];
    }
    
    constexpr const constant T& operator [] (size_t pos) const constant
    {
        return elements[pos];
    }
    
    threadgroup T& operator [] (size_t pos) threadgroup
    {
        return elements[pos];
    }
    constexpr const threadgroup T& operator [] (size_t pos) const threadgroup
    {
        return elements[pos];
    }
};

struct buffer_t
{
    float2 u_scale;
    int u_ctrl_count;
    spvUnsafeArray<float4, 128> u_ctrl_vec;
    float u_ratio;
    float2 u_scale_inv;
};

struct main0_out
{
    float2 textureCoordinate [[user(locn0)]];
    float4 gl_Position [[position]];
};

struct main0_in
{
    float3 attPosition [[attribute(0)]];
    float2 attTexcoord0 [[attribute(1)]];
};

vertex main0_out main0(main0_in in [[stage_in]], constant buffer_t& buffer)
{
    main0_out out = {};
    out.gl_Position = float4(in.attPosition, 1.0);
    if (buffer.u_ctrl_count > 0)
    {
        float _454;
        float4 _455;
        _455 = float4(0.0);
        _454 = 0.0;
        for (int _453 = 0; _453 < buffer.u_ctrl_count; )
        {
            float2 _301 = fma(-in.attTexcoord0, buffer.u_scale, buffer.u_ctrl_vec[_453].zw);
            float2 _304 = _301 * _301;
            float _315 = 1.0 / (fma(_304.x + _304.y, 0.25, 500.0 * buffer.u_ratio) + 9.9999997473787516355514526367188e-06);
            _455 += (buffer.u_ctrl_vec[_453] * _315);
            _454 += _315;
            _453++;
            continue;
        }
        float4 _331 = _455 / float4(_454);
        float2 _335 = fma(in.attTexcoord0, buffer.u_scale, -_331.zw);
        float2 _457;
        float _458;
        _458 = 0.0;
        _457 = float2(0.0);
        for (int _456 = 0; _456 < buffer.u_ctrl_count; )
        {
            float4 _347 = buffer.u_ctrl_vec[_456] - _331;
            float2 _351 = fma(-in.attTexcoord0, buffer.u_scale, buffer.u_ctrl_vec[_456].zw);
            float2 _354 = _351 * _351;
            float _365 = 1.0 / (fma(_354.x + _354.y, 0.25, 500.0 * buffer.u_ratio) + 9.9999997473787516355514526367188e-06);
            float2 _372 = _347.xy;
            float2 _374 = _347.zw;
            float2 _375 = _372 * _374;
            float2 _379 = _372 * float2(_347.wz);
            float _389 = _379.x - _379.y;
            float2 _392 = _335 * _365;
            float2 _417 = _374 * _374;
            _458 = fma(_365, _417.x + _417.y, _458);
            _457 += fma(float2(_392.yx), float2(_389, -_389), _392 * (_375.x + _375.y));
            _456++;
            continue;
        }
        out.textureCoordinate = fast::clamp(((_457 / float2(_458)) + _331.xy) * buffer.u_scale_inv, float2(0.0), float2(1.0));
    }
    else
    {
        out.textureCoordinate = fast::clamp(in.attTexcoord0, float2(0.0), float2(1.0));
    }
    out.gl_Position.z = (out.gl_Position.z + out.gl_Position.w) * 0.5;       // Adjust clip-space for Metal
    return out;
}

