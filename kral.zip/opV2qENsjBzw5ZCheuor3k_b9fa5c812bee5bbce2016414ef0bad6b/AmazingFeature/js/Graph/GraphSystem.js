
const { GraphUtils} = require("./Lib/Utils/GraphUtils");
const { BaseGroup } = require("./Lib/Utils/BaseGroup");
const { GraphManager } = require("./Lib/Utils/GraphManager");
const { ControlFlow } = require("./Lib/Utils/ControlFlow");
const APJS = require("../amazingpro");
const {GraphLifeCircleOrder, GraphLifeCircleType} = require("./Lib/Utils/GraphLifeCircle");

const { CGExpressionDetection : CGExpressionDetection100 } = require("./Lib/Nodes/CGExpressionDetection100");
const { CGSetVisibility : CGSetVisibility100 } = require("./Lib/Nodes/CGSetVisibility100");
const { CGGetSceneObjectNode : CGGetSceneObjectNode100 } = require("./Lib/Nodes/CGGetSceneObjectNode100");


function globalVariableInit() {
    // init all variables
        if (this.APJScene && this.APJScene.assetManager) {
        } else {
            console.error("AssertManager is undefined");
        }

}

function layerNameInit() {
    this.layerNameMap[0] = "Default Layer";
    this.layerNameMap[1] = "Layer 1";
    this.layerNameMap[2] = "Layer 2";
    this.layerNameMap[3] = "Layer 3";
    this.layerNameMap[4] = "Layer 4";
    this.layerNameMap[5] = "Layer 5";
    this.layerNameMap[6] = "Layer 6";
    this.layerNameMap[7] = "Layer 7";
    this.layerNameMap[8] = "Layer 8";
    this.layerNameMap[9] = "Layer 9";
    this.layerNameMap[10] = "Layer 10";
    this.layerNameMap[11] = "Layer 11";
    this.layerNameMap[12] = "Layer 12";
    this.layerNameMap[13] = "Layer 13";
    this.layerNameMap[14] = "Layer 14";
    this.layerNameMap[15] = "Layer 15";
    this.layerNameMap[16] = "Layer 16";
    this.layerNameMap[17] = "Layer 17";
    this.layerNameMap[18] = "Layer 18";
    this.layerNameMap[19] = "Layer 19";
    this.layerNameMap[20] = "Layer 20";
    this.layerNameMap[21] = "Layer 21";
    this.layerNameMap[22] = "Layer 22";
    this.layerNameMap[23] = "Layer 23";
    this.layerNameMap[24] = "Layer 24";
    this.layerNameMap[25] = "Layer 25";
    this.layerNameMap[26] = "Layer 26";
    this.layerNameMap[27] = "Layer 27";
    this.layerNameMap[28] = "Layer 28";
    this.layerNameMap[29] = "Layer 29";
    this.layerNameMap[30] = "Layer 30";
    this.layerNameMap[31] = "Layer 31";
    this.layerNameMap[32] = "Layer 32";
    this.layerNameMap[33] = "Layer 33";
    this.layerNameMap[34] = "Layer 34";
    this.layerNameMap[35] = "Layer 35";
    this.layerNameMap[36] = "Layer 36";
    this.layerNameMap[37] = "Layer 37";
    this.layerNameMap[38] = "Layer 38";
    this.layerNameMap[39] = "Layer 39";
    this.layerNameMap[40] = "Layer 40";
    this.layerNameMap[41] = "Layer 41";
    this.layerNameMap[42] = "Layer 42";
    this.layerNameMap[43] = "Layer 43";
    this.layerNameMap[44] = "Layer 44";
    this.layerNameMap[45] = "Layer 45";
    this.layerNameMap[46] = "Layer 46";
    this.layerNameMap[47] = "Layer 47";
    this.layerNameMap[48] = "Layer 48";
    this.layerNameMap[49] = "Layer 49";
    this.layerNameMap[50] = "Layer 50";
    this.layerNameMap[51] = "Layer 51";
    this.layerNameMap[52] = "Layer 52";
    this.layerNameMap[53] = "Layer 53";
    this.layerNameMap[54] = "Layer 54";
    this.layerNameMap[55] = "Layer 55";
    this.layerNameMap[56] = "Layer 56";
    this.layerNameMap[57] = "Layer 57";
    this.layerNameMap[58] = "Layer 58";
    this.layerNameMap[59] = "Layer 59";
    this.layerNameMap[60] = "Layer 60";
    this.layerNameMap[61] = "Layer 61";
    this.layerNameMap[62] = "Layer 62";
    this.layerNameMap[63] = "Layer 63";
}

const { SystemGraph } = require("./Lib/Utils/SystemGraph");
class GraphSystem extends SystemGraph {
    constructor() {
        super();
        this.isPreview = false;
    }

    setGlobalDataInit() {
        const graphManager = GraphManager.getInstance();
        if (!graphManager.variableInitFunc) {
            graphManager.variableInitFunc = globalVariableInit.bind(graphManager);
        }
        if (!graphManager.layerNameInitFunc) {
            graphManager.layerNameInitFunc = layerNameInit.bind(graphManager);
        }
    }
    
    registLifeCircle() {
        super.registLifeCircle();
        // *** regist total config
        this.registLifeCircleHandler(GraphLifeCircleType.onInit, {
            order: GraphLifeCircleOrder.onInit.graphConfig,
            tag: 'business generate config',
            fun: () => {
                this.usingBuiltInMediaPreview = false
                // algorithm subgraph map
                this.algorithmSubgraphMap = new Map();
                this.algorithmSubgraphMap.set("expressionDetect", "AlSubGraph_Sun22Mar2026232228GMT22trhi");
            },
        });
        // *** load Resource
        this.registLifeCircleHandler(GraphLifeCircleType.onInit, {
            order: GraphLifeCircleOrder.onInit.loadResource,
            tag: 'load Resource',
            fun: () => {
                this.loadResource();
            },
        });
        // *** variable init
        this.registLifeCircleHandler(GraphLifeCircleType.onInit, {
            order: GraphLifeCircleOrder.onInit.variableInit,
            tag: 'variable init',
            fun: () => {
                this.variableInit();
            },
        });
        // *** node init
        this.registLifeCircleHandler(GraphLifeCircleType.onInit, {
            order: GraphLifeCircleOrder.onInit.nodeInit,
            tag: 'node init',
            fun: () => {
                this.nodeInit();
            },
        });
        // *** node connect
        this.registLifeCircleHandler(GraphLifeCircleType.onInit, {
            order: GraphLifeCircleOrder.onInit.nodeConnect,
            tag: 'node connect',
            fun: () => {
                this.nodeConnect();
            },
        });
        // *** update port data
        this.registLifeCircleHandler(GraphLifeCircleType.onUpdate, {
            order: GraphLifeCircleOrder.onUpdate.updatePortData,
            tag: 'update port data',
            fun: () => {
            },
        });
    }

    loadResource() {
        if (this.sys && this.sys.resource && this.sys.APJScene && this.sys.APJScene.assetManager) {
        } else {
          console.error("AssertManager is undefined");
        }
    }

    variableInit() {
        // member variable init
    // init all variables
        if (this.APJScene && this.APJScene.assetManager) {
        } else {
            console.error("AssertManager is undefined");
        }

    }

    nodeInit(){
        // node init
        this.createNode("FacialExpressionDetection_1", CGExpressionDetection100, 2, 4);



        this.initNodeMedaAndInputs("FacialExpressionDetection_1",null,
            [{ portIndex: 0, value: "Face 0" },{ portIndex: 1, value: "Happy" }]);
        this.createNode("SetVisibility_2", CGSetVisibility100, 3, 2);



        this.initNodeMedaAndInputs("SetVisibility_2",null,
            [{ portIndex: 2, value: false }]);
        this.createNode("GetSceneObject_3", CGGetSceneObjectNode100, 1, 1);



        this.initNodeMedaAndInputs("GetSceneObject_3",null,
            [{ portIndex: 0, value: GraphUtils.guidToPointer("8164674546872324319", "14766218911180701337") }]);
    }

    nodeConnect(){
        // hash value map
        this.hashValueMap = new Map();
        // regist hashValueList
        // init map to store if edge is in circle
        ControlFlow.clearEdgeIsInCircle();
        //node connection
        this.handleExecEdgeConnection("FacialExpressionDetection_1", "SetVisibility_2", "f041a2ae-6615-8842-0d5b-9bb1fc886df3", 0, 0,undefined, false, "a0724258-2f7d-4180-65f9-de4cfe7467dd", { Input: "Normal", Output: "Normal" });
        this.handleDataEdgeConnection(null, "GetSceneObject_3", "SetVisibility_2", 0, 1, { Input: "Normal", Output: "Normal" },undefined,undefined, this.hashValueMap, "");
        //init callback table
        this.callbackNode.get(GraphLifeCircleType.onUpdate).push(this.nodes["FacialExpressionDetection_1"]);
        this.callbackNode.get(GraphLifeCircleType.resetOnRecord).push(this.nodes["FacialExpressionDetection_1"]);
        this.callbackNode.get(GraphLifeCircleType.beforeStart).push(this.nodes["SetVisibility_2"]);
        this.callbackNode.get(GraphLifeCircleType.resetOnRecord).push(this.nodes["SetVisibility_2"]);
    }
};

exports.GraphSystem = GraphSystem;
